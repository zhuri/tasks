<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use Maatwebsite\Excel\Concerns\WithColumnWidths;


class DataExport extends Model implements FromView, WithStyles, WithColumnWidths
{
    private $id, $xa, $barcode, $firstName, $lastName, $address,
        $addressReference, $route, $zone, $area, $b2b, $check, $receivedBy, $signature;

    private static $defaultCellWidth = 15;

    public function __construct($barcode)
    {
        $this->id = "123";
        $this->xa = "XA";
        $this->barcode = $barcode;
        $this->firstName = "First";
        $this->lastName = "Last";
        $this->address = "test";
    }

    public function view(): View
    {
        return view('excel', [
            'data' => [
                $this->id,
                $this->xa,
                $this->barcode,
                $this->firstName,
                $this->lastName,
                $this->address,
                $this->addressReference,
                $this->route,
                $this->zone,
                $this->area,
                $this->b2b,
                $this->check,
                $this->receivedBy,
                $this->signature
            ]
        ]);
    }

    public function styles(Worksheet $sheet)
    {
        $styleArray = [
            'borders' => [
                'allBorders' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    'color' => ['argb' => '00000000'],
                ],
            ],
        ];

        $sheet->getStyle('A3:N4')->applyFromArray($styleArray);
        $sheet->getStyle('A3:N3')->getFont()->setBold(true);
    }

    public function columnWidths(): array
    {
        return [
            'A' => self::$defaultCellWidth,
            'B' => self::$defaultCellWidth,
            'C' => self::$defaultCellWidth + 10,
            'D' => self::$defaultCellWidth,
            'E' => self::$defaultCellWidth,
            'F' => self::$defaultCellWidth,
            'G' => self::$defaultCellWidth,
            'H' => self::$defaultCellWidth,
            'I' => self::$defaultCellWidth,
            'J' => self::$defaultCellWidth,
            'K' => self::$defaultCellWidth,
            'L' => self::$defaultCellWidth,
            'M' => self::$defaultCellWidth,
            'N' => self::$defaultCellWidth
        ];
    }

}
