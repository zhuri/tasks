<?php

namespace App\Http\Services;

class ClosestSub
{

    /**
     * This is not the most efficient solution,
     * I am sure there are way better ones, but it was the one I came up most quickly up to
     * Generating all subsequent arrays and then compute their sums, the one with the smallest diff wins
     */
    public function compute($arr, $given_limit)
    {
        $subs = [];
        $this->createSubs($arr, 0, [], $subs);

        $diff = 99999;
        $searched = [];
        foreach ($subs as $sub) {
            $sum = array_sum($sub);
            $ldiff = $given_limit - $sum;
            if ($ldiff < $diff && $ldiff >= 0) {
                $diff = $ldiff;
                $searched = $sub;
            }
        }

        return $searched;
    }

    private function createSubs($arr, $index, $subarr, &$subs)
    {
        if ($index == count($arr)) {
            if (count($subarr) != 0) {
                if (count($subarr) > 1)
                    $subs[] = $subarr;
            }
        } else {
            $this->createSubs($arr, $index + 1, $subarr, $subs);
            $subarr[] = $arr[$index];
            $this->createSubs($arr, $index + 1, $subarr, $subs);
        }

        return;
    }
}
