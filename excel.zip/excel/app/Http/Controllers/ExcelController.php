<?php

namespace App\Http\Controllers;

use App\Http\Services\ClosestSub;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Routing\Controller as BaseController;
use App\DataExport;
use Milon\Barcode\DNS2D;
use \Illuminate\Http\Response;


class ExcelController extends BaseController
{
    private $closestSub;

    public function __construct(ClosestSub $closestSub)
    {
        $this->closestSub = $closestSub;
    }

    public function export()
    {
        //this is the solution to the first problem
        $out = $this->closestSub->compute([6, 10, 55, 40, 20], 67);

        $res = [
            "success" => true,
            "sequence" => $out,
            "sum" => array_sum($out)
        ];

        //this is the start of the excel file upload
        //the file is located in public_path() . "/storage/framework/laravel-excel/FILE_NAME"
        try {
            $file = (new DNS2D)->getBarcodePNGPath('4445645656', 'PDF417');
            $path = public_path().'/'.$file;
            Excel::download(new DataExport($path), 'test.xlsx');
        } catch (\Exception $e) {
            //log exception or smth $this->logger->log($e);
            $res["success"] = false;
        }

        return new Response(json_encode($res));
    }
}
