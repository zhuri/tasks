<html>
    <table>
        <thead>
            <tr>
                <th colspan="<?php echo e(count($data)); ?>" style="text-align: center;"><b>Driver Name: asd - Vendor: MyBox Express - Date: 2020-09-08 - Document Number 1230933413</b></th>
            </tr>
        </thead>
    </table>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>XA#</th>
                <th>Barcode</th>
                <th>First name</th>
                <th>Last name</th>
                <th>Address</th>
                <th>Address reference</th>
                <th>Route</th>
                <th>Zone</th>
                <th>Area</th>
                <th>B2B</th>
                <th>Check</th>
                <th>Received by</th>
                <th>Signature</th>
            </tr>
        </thead>
        <tbody>
        <tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key == 2): ?>
                    <td><img src="<?php echo e($item); ?>" height="100"></td>
                <?php else: ?>
                    <td style="text-align: left"><?php echo e($item); ?> </td>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        </tbody>
    </table>
</html>
<?php /**PATH /home/endrit/code/one2tek/excel/resources/views/excel.blade.php ENDPATH**/ ?>