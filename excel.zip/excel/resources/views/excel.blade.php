<html>
    <table>
        <thead>
            <tr>
                <th colspan="{{ count($data) }}" style="text-align: center;"><b>Driver Name: asd - Vendor: MyBox Express - Date: 2020-09-08 - Document Number 1230933413</b></th>
            </tr>
        </thead>
    </table>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>XA#</th>
                <th>Barcode</th>
                <th>First name</th>
                <th>Last name</th>
                <th>Address</th>
                <th>Address reference</th>
                <th>Route</th>
                <th>Zone</th>
                <th>Area</th>
                <th>B2B</th>
                <th>Check</th>
                <th>Received by</th>
                <th>Signature</th>
            </tr>
        </thead>
        <tbody>
        <tr>
            @foreach($data as $key => $item)
                @if($key == 2)
                    <td><img src="{{ $item }}" height="100"></td>
                @else
                    <td style="text-align: left">{{ $item }} </td>
                @endif
            @endforeach
        </tr>
        </tbody>
    </table>
</html>
